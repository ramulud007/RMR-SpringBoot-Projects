package com.SonarWithJava.Sonar_With_Java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SonarWithJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SonarWithJavaApplication.class, args);
	}

}
