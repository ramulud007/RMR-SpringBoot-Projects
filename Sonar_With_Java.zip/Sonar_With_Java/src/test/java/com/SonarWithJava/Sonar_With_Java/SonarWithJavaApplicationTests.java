package com.SonarWithJava.Sonar_With_Java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SonarWithJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
