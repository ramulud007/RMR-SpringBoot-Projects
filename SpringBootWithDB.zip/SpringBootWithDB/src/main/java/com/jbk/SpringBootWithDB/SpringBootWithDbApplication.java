package com.jbk.SpringBootWithDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithDbApplication.class, args);
	}

}
